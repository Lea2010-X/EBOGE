package Modelo;

public interface Blanco {
	void aplicar(Jugador jugadorObjetivo, Partida partida);
}

package Modelo;

public class CartaCronorruptura extends Carta implements Propia{

	public CartaCronorruptura(String imagenRuta) {
		super("Cronorruptura", TipoCarta.PROPIA, imagenRuta);
		
	}

    @Override
    public void aplicar(Jugador jugadorActivo, Partida partida) {
        int movimientoPrevio = jugadorActivo.getUltimoMovimiento();
        
        System.out.println("¡Retrocede lo que avanzó! (" + movimientoPrevio + " casillas)");
        
        jugadorActivo.retroceder(movimientoPrevio);
    }
}

package Modelo;

public class CartaSantuarioDelProtector extends Carta implements Maestra{
	
	public CartaSantuarioDelProtector(String rutaImagen) {
        super("Santuario del Protector", TipoCarta.MAESTRA, rutaImagen);
    }

	@Override
	public void aplicar(Jugador jugadorActivo, Partida partida) {
		// TODO Auto-generated method stub
		Mapa mapa = partida.getMapa();
        int posSiguiente = jugadorActivo.getPosicion() + 1;
        
        if (validarCasilla(posSiguiente, mapa)) {
                    	    
            mapa.cambiarTipoDeCasilla(posSiguiente, TipoCasilla.PROPIA);
            
            System.out.println("La casilla " + posSiguiente + " ahora es un Santuario Protector.");
            
        } else {
            System.out.println("La carta falla... la casilla siguiente no es válida o ya es especial.");
        }
	}
	
	public boolean validarCasilla(int posicionSiguiente, Mapa mapa) {
		return (mapa.identificarTipoDeCasilla(posicionSiguiente) != TipoCasilla.FINAL && mapa.identificarTipoDeCasilla(posicionSiguiente) != TipoCasilla.PROPIA);
	}
}

package Modelo;

public class CartaHechizoOscuro extends Carta implements Propia{

	public CartaHechizoOscuro(String imagenRuta) {
		super("Hechizo oscuro", TipoCarta.PROPIA, imagenRuta);
	}

	@Override
    public void aplicar(Jugador jugadorActivo, Partida partida) {
       Dado dado = partida.getDado();
       
       int tiradaExtra = dado.lanzar();
       
       int casillasTotales = partida.getTotalCasillas();
       jugadorActivo.avanzar(tiradaExtra, casillasTotales);  //Por ahora solo avanza, no verifica la casilla en la que cayo el jugador
        
    }

}

package Modelo;

public interface Maestra {
	void aplicar(Jugador jugadorActivo, Partida partida);
}

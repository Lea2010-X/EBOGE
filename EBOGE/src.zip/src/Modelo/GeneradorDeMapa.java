package Modelo;


import java.io.FileWriter;

public class GeneradorDeMapa {

    private static final int RONDAS_ESPERADAS = 5;

    private int anchoPanel;       // W
    private int altoPanel;        // H

    private int cantidadFilas;    // m
    private int cantidadColumnas; // n

    private int ladosDelDado;     // L

    private int anchoCasilla;     // wc
    private int altoCasilla;      // hc

    private Casilla[][] casillas;

    public Mapa generarMapa(int anchoPanel, int altoPanel, int ladosDelDado) {

        this.anchoPanel = anchoPanel;
        this.altoPanel = altoPanel;
        this.ladosDelDado = ladosDelDado;

        calcularDimensionesLogicas();

        casillas = new Casilla[cantidadFilas][cantidadColumnas];

        recorrerEspiralYCrearCasillas();

        return new Mapa(cantidadColumnas, cantidadFilas, anchoCasilla, altoCasilla, casillas);
    }

    private void calcularDimensionesLogicas() {

        double esperanzaDelDado = (ladosDelDado + 1) / 2.0;
        double casillasTeoricas = RONDAS_ESPERADAS * esperanzaDelDado;
        int cantidadCasillas = (int) Math.round(casillasTeoricas);

        double filasAproximadas = Math.sqrt((cantidadCasillas * (double) altoPanel) / (double) anchoPanel);
        int filas = Math.max(1, (int) Math.round(filasAproximadas));

        int columnas = (int) Math.ceil(cantidadCasillas / (double) filas);

        cantidadFilas = filas;
        cantidadColumnas = columnas;

        anchoCasilla = anchoPanel / cantidadColumnas;
        altoCasilla = altoPanel / cantidadFilas;
    }

    private void recorrerEspiralYCrearCasillas() {

        int limiteSuperior = 0;
        int limiteInferior = cantidadFilas - 1;
        int limiteIzquierdo = 0;
        int limiteDerecho = cantidadColumnas - 1;
        int indiceActual = 0;
        int totalCasillas = cantidadFilas * cantidadColumnas;

        while (limiteSuperior <= limiteInferior && limiteIzquierdo <= limiteDerecho && indiceActual < totalCasillas) {

            // Bajar por columna izquierda
            for (int fila = limiteSuperior; fila <= limiteInferior && indiceActual < totalCasillas; fila++) {
                crearCasillaEnPosicion(fila, limiteIzquierdo, indiceActual++, totalCasillas);
            }
            limiteIzquierdo++;

            // Ir a la derecha por fila inferior
            for (int columna = limiteIzquierdo; columna <= limiteDerecho && indiceActual < totalCasillas; columna++) {
                crearCasillaEnPosicion(limiteInferior, columna, indiceActual++, totalCasillas);
            }
            limiteInferior--;

            // Subir por columna derecha
            for (int fila = limiteInferior; fila >= limiteSuperior && indiceActual < totalCasillas; fila--) {
                crearCasillaEnPosicion(fila, limiteDerecho, indiceActual++, totalCasillas);
            }
            limiteDerecho--;

            // Ir a la izquierda por fila superior
            for (int columna = limiteDerecho; columna >= limiteIzquierdo && indiceActual < totalCasillas; columna--) {
                crearCasillaEnPosicion(limiteSuperior, columna, indiceActual++, totalCasillas);
            }
            limiteSuperior++;
        }
    }

    private void crearCasillaEnPosicion(int fila, int columna, int indiceCasilla, int totalCasillas) {
        TipoCasilla tipo;

        if (indiceCasilla == 0) {
            tipo = TipoCasilla.INICIO;
        } else if (indiceCasilla == totalCasillas - 1) {
            tipo = TipoCasilla.FINAL;
        } else {
            tipo = TipoCasilla.aleatorio();
        }

        casillas[fila][columna] = new Casilla(tipo, indiceCasilla);
    }
}



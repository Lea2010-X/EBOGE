package Modelo;

public interface Propia {
	void aplicar(Jugador jugadorActivo, Partida partida);
}

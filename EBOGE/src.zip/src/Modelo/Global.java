package Modelo;

import java.util.List;

public interface Global {
	void aplicar(List<Jugador> jugadores, Partida partida);
}

package Modelo;

import java.util.List;

public class CartaRuptura extends Carta implements Global{
	
	public CartaRuptura(String rutaImagen) {
        super("Ruptura", TipoCarta.GLOBAL, rutaImagen);
    }

	@Override
	public void aplicar(List<Jugador> listaJugadores, Partida partida) {

        List<Jugador> jugadores = partida.getJugadores();
        
        for (Jugador j : jugadores) {
            // Usamos el método 'retroceder' que añadimos a Jugador
            j.retroceder(5);
        }
	}    
}
